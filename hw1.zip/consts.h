#ifndef CONSTS_H
#define CONSTS_H

const int static ZERO = 0;
const int static ONE = 1;
const int static MINUS_ONE = -1;
const int static POSITIVE_UNBALANCED = 2;
const int static NEGATIVE_UNBALANCED = -2;

#endif // CONSTS_H